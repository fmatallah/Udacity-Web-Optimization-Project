# Udacity Website Optimization
This project is a part of Udacity's Frontend Nanodegree
It aims to optimize the given webpage as the below requirments:
  -```index.html``` achieves a PageSpeed score of at least 90 for Mobile & Desktop.
  -make the  ```views/js/main.js``` run at 60fps.

    
###### Installation
**1.** Clone this repo:
```
https://github.com/fmatallah/Udacity-Web-Optimization-Project
```

**2.** Run the index file
```
    open index.html
```

## Optimizations made for:
#### PageSpeed
- Minified `HTML` `JS` files
- Reduced Images sizes
- Used the `async` tag to link js file 
- Inlined the `CSS and JS` files to minimize No. of requests
- Moved ```print.css``` to the end so it doesn't interupt the load of the rest of the code


#### fps & ms
- Updated `changePizzaSizes` to make the slider ms < 5
- Replaced some `querySelector, querySelectorAll` calls to either `getElementByID`
or `getElementsByClassName` 
- Minified `HTML` `JS` files
- Used the `async` tag to link js file 
- Moved the declaration of some variables outside the loops 
- Reduced the No. of pizzaz from 200 to 50 as it is enough to cover the page
- Made some significant changes to `updatePositions` such as:
		-Saved the array length in the variable "leng", so the array's length property
   		is not accessed to check its value at each iteration
   		-Created variable 'result' instead of running `document.documentElement.scrollTop / 1250` multiple times

